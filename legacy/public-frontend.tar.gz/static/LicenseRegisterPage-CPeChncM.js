import{e as f,v as y,j as n,L as b}from"./index-B9xDrulr.js";/* empty css              */const v=`# Third-party notices

TurboTears depends on third-party software and data services. This file records the principal direct dependencies and does not replace the license texts shipped by their authors. A release must preserve all notices required by \`requirements.txt\`, \`front/package-lock.json\` and the container images in use.

## Software

- FastAPI — MIT License — <https://github.com/fastapi/fastapi>
- Aiogram — MIT License — <https://github.com/aiogram/aiogram>
- aiosqlite — MIT License — <https://github.com/omnilib/aiosqlite>
- FastF1 — MIT License for the library code — <https://github.com/theOehrly/Fast-F1>
- React and React DOM — MIT License — <https://github.com/facebook/react>
- React Router — MIT License — <https://github.com/remix-run/react-router>
- Chart.js — MIT License — <https://github.com/chartjs/Chart.js>
- styled-components — MIT License — <https://github.com/styled-components/styled-components>
- Vite — MIT License — <https://github.com/vitejs/vite>
- Inter — SIL Open Font License 1.1 — <https://github.com/rsms/inter>
- Space Grotesk — SIL Open Font License 1.1 — <https://github.com/floriankarsten/space-grotesk>

Python and JavaScript dependency trees include additional transitive packages. Before every public binary/container release, generate and archive a complete dependency license report for the exact lockfiles used by that release.

Redis 7.4 container licensing is governed by the license terms published for that Redis version. It is not covered by this repository's MIT License.

## Data and platforms

- OpenF1 is an independent project intended for education, personal learning, research and non-commercial fan engagement. Its availability does not grant a Formula 1 license: <https://openf1.org/>
- FastF1's MIT License covers the client library, not automatically the race, results, statistics, timing or telemetry obtained through upstream sources.
- Jolpica F1 provides an Ergast-compatible API: <https://api.jolpi.ca/ergast/>
- Telegram Bot Platform and Mini Apps are governed by Telegram's applicable developer and privacy terms: <https://telegram.org/tos/bot-developers>
- Formula 1 editorial word-mark use and other intellectual-property restrictions are described in the Formula 1 Guidelines: <https://www.formula1.com/en/information/guidelines.4EOKE9RRqevL4niTK9kWyt>

No item in this notice grants rights to third-party trade marks or data beyond the relevant right holder's terms.

`,I=`# Asset licensing register

This register documents provenance and license status. A file is not cleared for production merely because it exists in the repository or in \`app-assets.zip\`.

## Fonts loaded by the frontend

- Inter — Google Fonts / upstream project — SIL Open Font License 1.1.
- Space Grotesk — Google Fonts / upstream project — SIL Open Font License 1.1.

The frontend currently requests these fonts from Google Fonts. This external request must be reflected in the Privacy Policy or replaced with properly licensed self-hosted files in a later asset change.

## Flags

Status: provenance and license not verified in this change. Files are served from \`app/assets/country\` after unpacking \`app-assets.zip\`. Do not assume an open license until source, author, version and license are recorded for each set.

## Driver photographs

Status: intentionally not audited or modified in this change at the user's request. No license is asserted here. Production/public distribution requires a per-file source and license or removal.

## Team and organisation logos

Status: intentionally not audited or modified in this change at the user's request. Official logos and confusingly similar marks require permission from the respective right holders.

## Circuit illustrations and outlines

- \`front/public/static/circuit/Sepang Grand Prix.svg\` — derived circuit centreline from \`my-1999.geojson\` by Tomislav Bacinger, source: https://github.com/bacinger/f1-circuits/blob/master/circuits/my-1999.geojson ; project license: MIT (https://github.com/bacinger/f1-circuits/blob/master/LICENSE.md), copyright 2019–2025 Tomislav Bacinger. MIT permits copying, modification, public and commercial display worldwide without an expiry, provided copyright and license notices are preserved. The full notice is distributed as \`front/public/static/circuit/Sepang Grand Prix.LICENSE.txt\`. This is a schematic historical outline, not FIA-certified 2026 corner/zone data.

Status: intentionally not audited or modified in this change at the user's request. Existing SVG files and archived circuit materials remain pending a separate provenance and circuit-IP review.

## Application screenshots and other graphics

- \`app/profile_avatar_assets/{scarlet,cobalt,mint}-v1.png\` — original fictional racing-driver renders generated for this application with OpenAI's built-in image generation tool on 2026-10-10. No third-party photographs, real driver likenesses, logos or sponsors were supplied. Generation prompts and composition details are recorded in \`docs/avatar-assets.md\`; these are generated assets, not licensed photographs or official team graphics.

Status: pending. Screenshots may reproduce underlying photographs, logos, circuit graphics or protected interface elements and therefore require a derivative-material review.

## Admission rule

For every new visual or font asset, record before release:

1. repository path;
2. title and author/right holder;
3. original source URL or acquisition record;
4. exact license or written permission;
5. allowed media, territory, term and commercial-use status;
6. required attribution and proof-of-license location.

If these fields cannot be completed, the asset must not enter production.

`;function S(){const e=f.c(26),t=y().pathname==="/legal/assets",h=t?I:v;let o,c,i,l,s,r,a;if(e[0]!==h||e[1]!==t){const g=h.split(/^## /m).map(x);l="legal-page",e[9]===Symbol.for("react.memo_cache_sentinel")?(s=n.jsx(b,{to:"/legal/ip",children:"← Интеллектуальная собственность"}),e[9]=s):s=e[9];const m=t?"Реестр материалов":"Сторонние компоненты";e[10]!==m?(r=n.jsx("h1",{children:m}),e[10]=m,e[11]=r):r=e[11],e[12]===Symbol.for("react.memo_cache_sentinel")?(a=n.jsx("p",{children:"Источники и лицензии компонентов и материалов. Подробности сохранены на языке оригинала."}),i=n.jsx("summary",{children:"Открыть подробный реестр"}),e[12]=i,e[13]=a):(i=e[12],a=e[13]),o="ui-legal-register",c=g.map(T),e[0]=h,e[1]=t,e[2]=o,e[3]=c,e[4]=i,e[5]=l,e[6]=s,e[7]=r,e[8]=a}else o=e[2],c=e[3],i=e[4],l=e[5],s=e[6],r=e[7],a=e[8];let p;e[14]!==o||e[15]!==c?(p=n.jsx("div",{className:o,children:c}),e[14]=o,e[15]=c,e[16]=p):p=e[16];let d;e[17]!==i||e[18]!==p?(d=n.jsxs("details",{children:[i,p]}),e[17]=i,e[18]=p,e[19]=d):d=e[19];let u;return e[20]!==l||e[21]!==s||e[22]!==r||e[23]!==a||e[24]!==d?(u=n.jsxs("article",{className:l,children:[s,r,a,d]}),e[20]=l,e[21]=s,e[22]=r,e[23]=a,e[24]=d,e[25]=u):u=e[25],u}function T(e,t){return n.jsxs("section",{children:[n.jsx("h2",{children:e.heading}),e.paragraphs.map(L)]},t)}function L(e,t){return n.jsx("p",{children:e.replace(/`/g,"").replace(/<(https?:\/\/[^>]+)>/g,"$1")},t)}function x(e){const[t,...h]=e.replace(/^# /,"").split(`
`);return{heading:t,paragraphs:h.join(`
`).trim().split(/\n\n+/)}}export{S as default};
